<?php
session_start();
if(@file_exists("installer.php"))
{
	header("Location: installer.php?stage=1");
}
session_start();
include("includes/functions.php");
include("includes/config.php");
define('PHP_FIREWALL_REQUEST_URI', strip_tags( $_SERVER['REQUEST_URI'] ) );
define('PHP_FIREWALL_ACTIVATION', true );
if ( is_file( @dirname(__FILE__).'/php-firewall/firewall.php' ) )
	include_once( @dirname(__FILE__).'/php-firewall/firewall.php' );
	require_once("phpfastcache/phpfastcache.php");
// Check for login
if($_GET['inside'] == "yes" || isset($_SESSION['username']) && isset($_SESSION['password']) && !$_SESSION['level'] == "banned") {
##### CHECK FOR FIRST-TIME USER #####
$checker = mysql_fetch_array(mysql_query("SELECT * FROM users WHERE username = '$_SESSION[username]'"));

if($checker['firsttime'] == "") {
header('location: in.php?firstime=yes');
die();
} else {
header('location: in.php');
die();
}
}


elseif($_GET['method'] == "login") {

$username = $_POST['username'];
$password = $_POST['password'];

if(empty($username) || empty($password)) {
header('location: index.php?error=2');
die();
}

###############################################################
##															 ##
##           		 PANEL REPORT LOGS SENDER                ##
##															 ##
###############################################################################################################################
																															 ##
$logs = @mysql_fetch_array(mysql_query("SELECT `reports` FROM config"));													 ##
																															 ##
if($logs['reports'] != "true") {																							 ##
																															 ##
$a1 = $_SERVER['HTTP_HOST'];																								 ##
$a2 = $_SERVER['REQUEST_URI'];																								 ##
$report = @file_get_contents("http://www.powerpanel.duosystems.net/reports.php?callback=true&data=http://". $a1 ."". $a2."");##
																															 ##
}																															 ##
###############################################################################################################################
##															 ##
##                END OF PANEL REPORT LOGS SENDER            ##
##															 ##
###############################################################



// Clean out and encrypt strings

$username = clean($username);
$password = encrypt($password);

// We have encrypted and cleaned the strings.

$check = mysql_query("SELECT * FROM users WHERE username = '$username'");
while($rows = mysql_fetch_array($check)) {
$realpass = $rows[password];
$level = $rows[level];
$realuser = $rows[username];
}

$rows3 = mysql_num_rows($check);


if($rows3 == "0") {
header('location: index.php?error=1');
die();
}

if($password == $realpass) {
// Set the sessions
$_SESSION['username'] = $realuser;
$_SESSION['password'] = $password;
$_SESSION['level'] = $level;

##### CHECK FOR FIRST-TIME USER #####
$checker = mysql_fetch_array(mysql_query("SELECT * FROM users WHERE username = '$_SESSION[username]'"));

if($checker['firsttime'] == "") {
header('location: in.php?firstime=yes');
die();
} elseif($_SESSION[level] == "banned") {
header('location: index.php?banned=true');
} else {
header('location: index.php?inside=yes');
die();
}
}
else {
session_destroy();
header('location: index.php?error=1');
die();
}



}
?>
<?
if(isset($_SESSION['username']) && isset($_SESSION['password']) && isset($_SESSION['level'])) {
header('location: in.php');
die();
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="description" content="<?php echo $strLoginInterface . ' ' . $strPoweredBy . ' phpSecurePages'; ?>">
<meta name="keywords" content="phpSecurePages">
<title>Welcome To Power Panel v2.0</title>
<SCRIPT LANGUAGE="JavaScript">
<!--
//  ------ check form ------
function checkData() {
        var f1 = document.forms[0];
        var wm = "<?php echo $strJSHello; ?>\n\r\n";
        var noerror = 1;

        // --- entered_login ---
        var t1 = f1.entered_login;
        if (t1.value == "" || t1.value == " ") {
                wm += "<?php echo $strLogin; ?>\r\n";
                noerror = 0;
        }

        // --- entered_password ---
        var t1 = f1.entered_password;
        if (t1.value == "" || t1.value == " ") {
                wm += "<?php echo $strPassword; ?>\r\n";
                noerror = 0;
        }

        // --- check if errors occurred ---
        if (noerror == 0) {
                alert(wm);
                return false;
        }
        else return true;
}
//-->
</SCRIPT>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $strLoginInterface; ?></title>
<style>
body{font-family:arial;color: white;background: url(http://mibbitcast.ca/v2/newpanel/images/back1.jpg) no-repeat center center fixed;text-align:center;}
#error{margin:1em auto;background:#FA4956;color:#FFFFFF;border:8px solid #FA4956;font-weight:bold;width:500px;text-align:center;position:relative;}
#entry{margin:2em auto;background:#fff;border:8px solid #eee;width:500px;text-align:left;position:relative;}
#entry a, #entry a:visited{color:#0283b2;}
#entry a:hover{color:#111;}
#entry h1{text-align:center;background:#3B8CCA;color:#fff;font-size:16px;padding:16px 25px;margin:0 0 1.5em 0;border-bottom:1px solid #007dab;}
#entry p{text-align:center;}
#entry div{margin:.5em 25px;background:#eee;padding:4px;text-align:right;position:relative;}
#entry label{float:left;line-height:30px;padding-left:10px;}
#entry .field{border:1px solid #ccc;width:280px;font-size:12px;line-height:1em;padding:4px;}
#entry div.submit{background:none;margin:1em 25px;text-align:center;}
#entry div.submit label{float:none;display:inline;font-size:11px;}
#entry button{border:0;padding:0 30px;height:30px;line-height:30px;text-align:center;font-size:16px;font-weight:bold;color:#fff;background:#3B8CCA;cursor:pointer;}
</style>
</head>
<body>

<!-- Place your logo here -->
        <P><IMG SRC="http://mibbitcast.ca/v2/newpanel/images/logo.png"  ALT="PowerPanel logo"></P>
<!-- Place your logo here -->

<?php
// check for error messages
if ($phpSP_message) {
        echo '<div id="error">'.$phpSP_message.'</div>';
        }
?>

<!-- ------ Have you set up phpSP with no users?  ------ -->
        <?php if ($useDatabase == false AND $useData == true AND $cfgLogin[1] == "") echo '<p style="font-family:arial;font-size:22px;color:red;font-weight:bold;">WEBMASTER: It looks like you have no users or passwords set up! <br>
        <br><span style="font-size:18px;">If you are not using a database, make sure you have configured<br>at least one user in config.php (around line 85).</span></p>'; ?>
<!-- ------ Initial Setup (No Users) check ends here ------ -->

<div id="login"><form method="post" action="?method=login" onSubmit="return checkData()">

<label><strong>username:</strong><br />
		      <input name="username" type="text" id="username" onChange="check(this.value)" /><div id="results"></div>
  </label>
          <br />
		  <br />
	<strong>password:</strong><br />
	<label>
	<input name="password" type="password" id="password" />
	</label>
	<br />
	<br />
	<label>
	<input type="submit" name="Submit" value="login" />
	</label>
</form>
	
		
<?php
if($_GET['error'] == "1") {
echo("		</div>
		<div id=\"error\">");
echo("<strong>Error:</strong> The username and/or password you entered was incorrect");
echo("		</div>");
}
elseif($_GET['error'] == "2") {
echo("		</div>
		<div id=\"error\">");
echo("<strong>Error:</strong> You must fill in both fields");
echo("		</div>");
}
elseif($_GET['banned'] == "true") {
echo("		</div>
		<div id=\"error\">");
echo("<strong>Error:</strong> It appears your account is disabled or banned! Please contact an administrator immediately");
echo("		</div>");
}
else {
echo("		</div>");
}
?>
		

<div id="poweredby"><strong>Forgot your password? Contact The Owner Of Your Station.</strong></a><br />
		    <br />
		<br />
		<br />
		Powered by <strong>PowerPanel V2.0</strong><br />
		
		<strong>Recreated and Remastered by Rob Legroulx</strong><br />
		
		<strong>Want this for your station?</strong><br />
		Drop me a line: http://radiolium.com/facebook
</div>
</body>

</html>