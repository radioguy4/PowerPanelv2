How To Install Power Panel

	Once again, thanks for downloading Power Panel V2.0! Power Panel features quite a lot of cool tools
	for you to use to run your Radio Station Website/Fansite.

	This panel has been edited by Robert Legroulx, because of the fact that parts of
	the code was made by another coder this will always be free open source the main stuff 
	I have changed Is the login page by adding an Secure Login page along with firewall protection, cache and a timeout session. 
	
	So please, edit the code as you wish! All I ask is that you keep the disclaimers and the "POWERpanel brand name" In honours of the original creator.

	To install the panel first CHMOD the following files to 777 or 07777:
	
	'includes/sql.php'
	'includes/config.php'
	
	Once you have done this open installer.php and go through the stages!
	Make Sure To Delete "installer.php" after your done with the Install has It will not be recommend to keep on the server.
	
	Enjoy! your new Radio Station Panel
	Rob 
	
	If you have questions or Issue with this panel feel free to contact me at radiolium.com/facebook
	