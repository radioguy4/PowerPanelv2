<?php

include("config.php");
$useData = true;  
$useDatabase = false;
if($_GET['username'] && !empty($_GET['username'])) {

$username = $_GET['username'];

$checkz = mysql_num_rows(mysql_query("SELECT * FROM users WHERE username = '$username'"));

if($checkz == "0") {
echo("<div style='margin-top: 4px;'><img src='images/invalid.gif' alt='Invalid Username!' /></div>");
}
elseif($checkz == "1") {
echo("<div style='margin-top: 4px;'><img src='images/valid.gif' alt='Valid Username!' /></div>");
}
// check if login is necessary

// Check if secure.php has been loaded correctly
if ( !defined("LOADED_PROPERLY") || isset($_GET['cfgProgDir']) || isset($_POST['cfgProgDir'])) {
        echo "Parsing of phpSecurePages has been halted!";
        exit();
}

if (!isset($entered_login) && !isset($entered_password)) {
        // use data from session
        session_start();
        // session hack to make sessions on old php4 versions work
        if (phpversion() > 4.0) {
                if (isset($_SESSION['login'])) $login = $_SESSION['login'];
                if (isset($_SESSION['password'])) $password = $_SESSION['password'];
                }
        }
else {
        // use entered data
        session_start();
        // session hack to make sessions on old php4 versions work
        if (phpversion() <= 4.0) {
                session_unregister("login");
                session_unregister("password");
                }
        // encrypt entered login & password
        $login = $entered_login;
        if ($passwordEncryptedWithMD5 && function_exists(md5)) {
                $password = md5($entered_password);
                }
        else {
                $password = $entered_password;
                }
        // session hack to make sessions on old php4 versions work
        if (phpversion() > 4.0) {
                $_SESSION['login'] = $login;
                $_SESSION['password'] = $password;
                }
        else {
                session_register("login");
                session_register("password");
                }
        }

if (!isset($login)) {
        // no login available
        include($cfgProgDir . "index.php");
        exit;
        }

if (!isset($password)) {
        // no password available
        $phpSP_message = $strNoPassword;
        include($cfgProgDir . "index.php");
        exit;
        }

// login and password variables exist
// continue to checking them

}

?>
