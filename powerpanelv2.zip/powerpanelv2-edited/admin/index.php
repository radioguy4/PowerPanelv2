<?PHP
                $cfgProgDir =  'phpSecurePages/';
                include($cfgProgDir . "secure.php");
        ?>
<?php
include_once '/public/SafeGuardPro/protect.php';
header('Location: ../index.php');
die();

?>